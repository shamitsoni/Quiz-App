export async function handler() {
  return {
    statusCode: 503,
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      message: "Lambda bootstrapped. Deployment in progress."
    })
  };
}